import React from "react";

const Footer = () => {
	return <div>copyright by fpolyShop</div>;
};

export default Footer;
